The certificates are available in PEM (base64-encoded) or DER (binary) format. Please use the appropriate format for your solution. Both formats contain the same certificate.

For more information, please see: https://pagero.github.io/communication/certificates-and-keys/.

Best regards,
Pagero
