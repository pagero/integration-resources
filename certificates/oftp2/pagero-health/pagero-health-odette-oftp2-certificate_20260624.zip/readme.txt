This is Pagero Odette OFTP2 certificate to use for signing and encryption:
ODETTE27376.CER

Theses are the Odette chain certificates:
Odette CA-certificate: ODETTE Issuing G3.CER
Odette root certificate: ODETTERootG3.CER

For aditional information, please see: https://pagero.github.io/communication/certificates-and-keys/.

Best regards,
Pagero