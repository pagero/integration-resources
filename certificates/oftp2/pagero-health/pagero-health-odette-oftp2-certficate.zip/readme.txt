This is Pagero Odette OFTP certificate to use for signing and encryption:
ODETTE23734.CER

Theses are the Odette chain certificates:
Odette CA-certificate: ODETTE Issuing G3.CER
Odette root certificate: ODETTERootG3.cer

For aditional information, please see: https://pagero.github.io/communication/certificates-and-keys/.

Best regards,
Pagero