This is Pagero Odette OFTP certificate to use for signing and encryption:
ODETTE19637.CER

Theses are the Odette certificate chain certificates:
Odette CA-certificate: ODETTE-Issuing-CA.cer
Odette root certificate: ODETTE-Root.cer

For aditional information, please see: https://pagero.github.io/communication/certificates-and-keys/.

Best regards,
Pagero