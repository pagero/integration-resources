For more information, please see: https://pagero.github.io/communication/certificates-and-keys/.

Best regards,
Pagero